package com.capg.service;

import java.util.List;
import java.util.Optional;
import java.util.Scanner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capg.bean.InvoiceCal;
import com.capg.dao.InvoiceDao;
import com.capg.dao.InvoiceDaoImpl;
import com.capg.exception.InvoiceException;

@Service
public class InvoiceServiceImpl implements InvoiceService {
	@Autowired
	InvoiceDao invoiceDao;

	static Scanner sc = new Scanner(System.in);

	@Override
	public InvoiceCal createInvoice(InvoiceCal obj) {

		obj.setId((int) (Math.random() * 1000 + 1));
		double d = 5 * obj.getDistance() * obj.getWeight();
		obj.setCgst(0.035 * d);
		obj.setSgst(0.035 * d);
		double amt = obj.getCgst() + obj.getSgst() + d;

		obj.setAmount(amt);

		return invoiceDao.save(obj);
	}

	@Override
	public InvoiceCal updateInvoice(InvoiceCal obj, int id) throws InvoiceException {
		try {

			Optional<InvoiceCal> obj1 = invoiceDao.findById(id);
			if (obj1.isPresent()) {
				InvoiceCal i = obj1.get();
				i.setDistance(obj.getDistance());
				i.setWeight(obj.getWeight());
				double d = 5 * obj.getDistance() * obj.getWeight();
				obj.setCgst(0.035 * d);
				obj.setSgst(0.035 * d);
				double amt = obj.getCgst() + obj.getSgst() + d;

				obj.setAmount(amt);

				invoiceDao.save(i);
				return i;
			}
		} catch (Exception e) {
			throw new InvoiceException("Id does not exists");
		}

		return null;

	}

	@Override
	public void deleteInvoice(int id) throws InvoiceException {

		try {
			invoiceDao.deleteById(id);
		} catch (Exception e) {
			throw new InvoiceException("Id does not exists");
		}

	}

	@Override
	public List<InvoiceCal> viewAllInvoice() {

		return invoiceDao.findAll();

	}

	@Override
	public InvoiceCal findSingleInvoice(int id) throws InvoiceException {
		try {
			return invoiceDao.findById(id).get();
		} catch (Exception e) {
			throw new InvoiceException("Id does not exists");
		}
	}

}
