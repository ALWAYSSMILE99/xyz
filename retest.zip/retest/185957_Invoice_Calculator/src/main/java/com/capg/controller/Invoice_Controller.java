package com.capg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.capg.bean.InvoiceCal;
import com.capg.exception.InvoiceException;
import com.capg.service.InvoiceServiceImpl;

@RestController
public class Invoice_Controller {
	@Autowired
	InvoiceServiceImpl invoiceServiceImpl;
	
	
	@PostMapping(value = "/enter", produces = "application/json", consumes = MediaType.APPLICATION_JSON_VALUE)
	public InvoiceCal createAccount(@RequestBody InvoiceCal obj) {
		return invoiceServiceImpl.createInvoice(obj);
	}
	
	
	@PutMapping(value = "/update/{id}", produces = "application/json", consumes = MediaType.APPLICATION_JSON_VALUE)
	public InvoiceCal updateInvoice(@RequestBody InvoiceCal obj,@PathVariable int id)throws InvoiceException {
		return invoiceServiceImpl.updateInvoice(obj,id);
		
	}
	
	@DeleteMapping(value = "/delete/{id}")
	public String updateInvoice(@PathVariable int id)throws InvoiceException {
		invoiceServiceImpl.deleteInvoice(id);
		 return "Deleted Invoice obj with id"+id;
		
	}
	
	@GetMapping(value = "/shows")
	public List<InvoiceCal> showAllInvoice() {
		
		 return  invoiceServiceImpl.viewAllInvoice();
	}
	
	@GetMapping(value = "/show/{id}")
	public InvoiceCal viewById(@PathVariable int id)throws InvoiceException {
		
		 return  invoiceServiceImpl.findSingleInvoice(id);
	}


}
