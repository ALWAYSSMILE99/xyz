package com.insurancecalculator._Insurance_Calculator.insurencedao;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.insurancecalculator._Insurance_Calculator.Exception.InsuranceException;
import com.insurancecalculator._Insurance_Calculator.entity.Insurance;
/*
 *Authorname:Ajay Mehta
 *mailid:ajay.a.mehta@capgemini.com
 *Version:1.0
 *Description:this class perform all backend function of this project means all database related function based 
 *on comming data from service layer.
 */
@Repository
public class InsuranceDAO implements IInsuranceDAO {
@PersistenceContext
EntityManager entityManager;
/*
 * Method name:-deleteInsurance 
 * Method Description:-this method delete record from database based on id
 * 
 */
@Override
public Insurance deleteInsurance(int id) {
	Insurance insurance=entityManager.find(Insurance.class, id);
	if(insurance==null)
	{

		throw new InsuranceException("Invalid id");
	}
	entityManager.remove(insurance);
	return insurance;
}
/*
 * Method name:-GetSingleInsurance 
 * Method Description:-this method fetch record from database based on given id on its parameter
 * 
 */
@Override
public Insurance GetSingleInsurance(int id) {
	Insurance insurance=entityManager.find(Insurance.class, id);
	if(insurance==null)
	{
		throw new InsuranceException("Invalid id");
	}
	return insurance;
}

/*
 * Method name:-AddInsurance 
 * Method Description:-this method add record to database based on given 'insurance' class object comming as a parameter
 * and it is generating Insurance amount based on purchase year and onRoad price and then adding to database
 * 
 */

@Override
public Insurance AddInsurance(Insurance insurance) {
	if(insurance==null)
	{
		throw new InsuranceException("Invalid Details");
	}
	double insurancePrice=CalculateVahicleInsurance(insurance.getPurchaseYear(),insurance.getOnRoadPrice());
	insurance.setInsuranceAmount(insurancePrice);
	
	LocalDate d=LocalDate.now();

	int year=d.getYear()+1;
	int month=d.getMonthValue();
	int day=d.getDayOfMonth();
	String date=Integer.toString(year)+"-"+Integer.toString(month)+"-"+Integer.toString(day);
	try {
		
		Date expdate = new SimpleDateFormat("yyyy-MM-dd").parse(date);
		insurance.setExpDate(expdate);
	} catch (ParseException e) {
		throw new InsuranceException();
	}
	
			entityManager.persist(insurance);
	return insurance;
}
/*
 * Method name:-UpdateInsurance 
 * Method Description:-this method updating record in the database 
 * 
 */
@Override
public Insurance UpdateInsurance(Insurance insurance) {
	if(insurance==null)
	{
		throw new InsuranceException("Invalid Details");
	}
	entityManager.merge(insurance);
	return insurance;
}
/*
 * Method name:-viewAllInsuranceDetails 
 * Method Description:-this method returning all the record in the database  
 * 
 */
@Override
public List<Insurance> viewAllInsuranceDetails(int year) {

	TypedQuery<Insurance> typedQuery=entityManager.createQuery("select insurance from Insurance insurance where insurance.purchaseYear=:year",Insurance.class);
	typedQuery.setParameter("year", year);
	List<Insurance> allInsurancedetails=typedQuery.getResultList();
	
	return allInsurancedetails;
}
/*
 * Method name:-CalculateVahicleInsurance 
 * Method Description:-this method is calculating and returning Insurance amount based on 
 *  purchase year and onRoad price
 * 
 */
public double CalculateVahicleInsurance(int purchaseYear,double onRoadPrice)
{
	int totalYearofPurchase=2019-purchaseYear;
	double percentage=((5*totalYearofPurchase)/100.0);
	double depreciatedcost=(onRoadPrice-(percentage*onRoadPrice));
	double insurancePrice=depreciatedcost*(2.5/100);
	return insurancePrice;
	
}
}
