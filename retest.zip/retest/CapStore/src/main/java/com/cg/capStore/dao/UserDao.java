package com.cg.capStore.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.capStore.bean.CapUser;


public interface UserDao extends JpaRepository<CapUser,String>{

}
