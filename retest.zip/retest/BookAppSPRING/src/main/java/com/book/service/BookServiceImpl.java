package com.book.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.book.bean.Book;
import com.book.dao.BookDao;
import com.book.exception.BookException;
@Service
public class BookServiceImpl implements BookService {
	@Autowired
	BookDao bookDao;
	

	@Override
	public List<Book> addBook(Book b) throws BookException {
		
		try {
	        bookDao.save(b);
	        return bookDao.findAll();
	        }catch(Exception e) {
	            throw new BookException(e.getMessage());
	        }
	}

	@Override
	public Book getBookById(int id) throws BookException {
		
		try
		{
			return bookDao.findById(id).get();
		}
		catch (Exception ex)
		{
			throw new BookException(ex.getMessage());
		}
	}

	@Override
	public void deleteBook(int id) throws BookException {
		try
		{
			bookDao.deleteById(id);
		}
		catch(Exception e)
		{
			throw new BookException(e.getMessage());
		}
		
	}

	@Override
	public List<Book> getAllBooks() throws BookException {
		try
		{
			return bookDao.findAll();
		}
		catch(Exception e)
		{
			throw new BookException(e.getMessage());
		}
	
	}

	@Override
	public List<Book> getBookByAuthor(String author) throws BookException {
		try
		{
		return bookDao.getBookByAuthor(author);	
		}
		catch(Exception e) {
		throw new BookException(e.getMessage());
	}
	}

	@Override
	public List<Book> updateBook(int id, Book b) throws BookException {
		try
		{
			Optional<Book> optional=bookDao.findById(id);
			if(optional.isPresent())
			{
				Book book=optional.get();
				book.setName(b.getName());
				book.setAuthor(b.getAuthor());
				book.setPrice(b.getPrice());
				
				bookDao.save(book);
				return getAllBooks();
			}
			else
			{
				throw new BookException("Customer with Id"+id+" does not exist");	
			}
		}
			catch(Exception e) {
	            throw new BookException(e.getMessage());
			
	}
	}
	}



